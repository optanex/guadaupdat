#!/bin/sh

x=0
while [ $x=0 ]
do
    clear
    echo "Bienvenido a GuadaUpdat"
    echo "¿Desea instalar las? (s/n)"
    echo "Si escoge No, volverá a este menú. Para salir de SuDater aunque haya escogido Si, por favor cierre el terminal (Aunque mates el proceso los cambios se habrán guardado)"
    read answer

    case "$answer" in
        s)
        clear
        echo "Descargando Actualización 1/1"
        wget https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb
        sleep 3
        clear
        echo "Instalando Actualización 1/1"
        gdebi google-chrome-stable_current_amd64.deb
        sleep 3
        clear
        echo "Actualizaciones Instaladas / Anuladas - Limpiando Procesos..."
        sleep 3
        clear
        x=1
        ;;
        n)
        echo "Volviendo al menú..."
        sleep 3
        clear
        x=1
        ;;
        *)
        clear
        echo "Error: Debes escoger entre Si y No"
        sleep 3
        ;;
    esac

done
